package week3.day2;

public abstract class University {
	
	public void pg() {
		System.out.println("PG");
	}
	
	public abstract void ug();

}
