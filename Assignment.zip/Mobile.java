package week3.day2;

public class Mobile {
	
	public void sendMsg(String text) {
		System.out.println(text);
	}
	public void makeCall(String name) {
		System.out.println(name);
	}
	public void saveContact(String name, int a) {
		System.out.println(name+a);
	}

	public static void main(String[] args) {
		
		

	}

}
