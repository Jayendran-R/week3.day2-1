package week3.day2;

public class Tv extends SamsungTV{

	public static void main(String[] args) {
		
		Tv tvNew = new Tv();
		
		tvNew.samsungworld();
		tvNew.youtube();
		tvNew.amazonPrime();
		tvNew.netflix();
		
		
	}

}
