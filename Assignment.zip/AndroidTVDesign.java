package week3.day2;

public interface AndroidTVDesign {
	
	public void youtube();
	
	public void amazonPrime();
	
	public void netflix();

}
