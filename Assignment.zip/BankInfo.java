package week3.day2;

public class BankInfo {
	
	public void saving() {
		System.out.println("Bank Saving");
	}
	
	public void fixed() {
		System.out.println("Bank Fixed Deposit");
	}
	
	public void deposit() {
		System.out.println("Bank Deposit");
	}

	public static void main(String[] args) {
		

	}

}
