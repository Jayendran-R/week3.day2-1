package week3.day2;

public class Android extends Mobile {
	
	public void takeVideo() {
		System.out.println("call");
	}

	public static void main(String[] args) {
		

	}

}
