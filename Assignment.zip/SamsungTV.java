package week3.day2;

public class SamsungTV implements AndroidTVDesign {
	
	public void samsungworld() {
		System.out.println("Welcome to Samsung");
	}

	public void youtube() {
		// TODO Auto-generated method stub
		System.out.println("Youtube");
	}

	public void amazonPrime() {
		// TODO Auto-generated method stub
		System.out.println("Amazon");
	}

	public void netflix() {
		// TODO Auto-generated method stub
		System.out.println("Netflix");
	}

}
