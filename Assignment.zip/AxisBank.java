package week3.day2;

public class AxisBank extends BankInfo {
	
	public void deposit() {
		System.out.println("Axis Bank Deposit");
	}

	public static void main(String[] args) {
		
		AxisBank obj = new AxisBank();
		
		obj.deposit();

	}

}
